#include "ButtonResponse.h"
#include "Robot.h"
#include<iostream>

ButtonResponse::ButtonResponse() {
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(Robot::chassis.get());
	Requires(&Robot::intakeud);
	Requires(&Robot::intakeio);
}

// Called just before this Command runs the first time
void ButtonResponse::Initialize() {

}

// Called repeatedly when this Command is scheduled to run
void ButtonResponse::Execute() {
		//get value from joystick
//		LAxisY = myJS_2->GetRawAxis(1);
//		LAxisX = myJS_2->GetRawAxis(0);
//		RAxisY = myJS_2->GetRawAxis(5);
//		RAxisX = myJS_2->GetRawAxis(4);
//		myPOV = myJS_2->GetPOV();
		A = myJS_2->GetRawButton(1);
		B = myJS_2->GetRawButton(2);
		X = myJS_2->GetRawButton(3);
		Y = myJS_2->GetRawButton(4);
//		LB = myJS_2->GetRawButton(5);
//		RB = myJS_2->GetRawButton(6);
//		BACK = myJS_2->GetRawButton(7);
//		START = myJS_2->GetRawButton(8);
//		LP = myJS_2->GetRawButton(9);
//		RP = myJS_2->GetRawButton(10);
//		LT=myJS_2->GetRawAxis(2);
//		RT=myJS_2->GetRawAxis(3);
		//end

		if(A==1){
			Robot::intakeud.up();
		}else if(B==1){
			Robot::intakeud.down();
		}else{
			Robot::intakeud.off();
		}

		if(X==1){
			Robot::intakeio.in();
		}
		else if(Y==1){
			Robot::intakeio.out();
		}else{
			Robot::intakeio.off();
		}
}

// Make this return true when this Command no longer needs to run execute()
bool ButtonResponse::IsFinished() {
	return false;
}

// Called once after isFinished returns true
void ButtonResponse::End() {

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void ButtonResponse::Interrupted() {

}
