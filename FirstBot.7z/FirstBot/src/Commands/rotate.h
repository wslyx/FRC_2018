#ifndef rotate_H
#define rotate_H

#include "Commands/Command.h"

class rotate : public Command {
public:
	double speed;
	rotate(double x_speed);   //+value ��ʱ�� -value ˳ʱ��
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif  // rotate_H
