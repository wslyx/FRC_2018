#ifndef Autopilot_2_H
#define Autopilot_2_H

#include <Commands/CommandGroup.h>

class Autopilot_2 : public CommandGroup {
public:
	Autopilot_2();
};

#endif  // Autopilot_2_H
