#ifndef forward_H
#define forward_H

#include "Commands/Command.h"

class forward : public Command {
public:
	double speed;
	forward(double x_speed);
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif  // forward_H
