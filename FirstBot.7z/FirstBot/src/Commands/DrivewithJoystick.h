#ifndef DrivewithJoystick_H
#define DrivewithJoystick_H

#include "Commands/Command.h"
#include "Joystick.h"

class DrivewithJoystick : public Command {
public:
	DrivewithJoystick();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
private:
	//Init
	frc::Joystick *myJS_1 = new frc::Joystick(0);					//�ֱ�
	double LAxisY=0,LAxisX=0,RAxisY=0,RAxisX=0,LT=0,RT=0;		//�ֱ�����
	bool A=0,B=0,X=0,Y=0,LB=0,RB=0,LP=0,RP=0,BACK=0,START=0;
	int myPOV=0;												//�ֱ�����

	double now=0;
	//end

};

#endif  // DrivewithJoystick_H
