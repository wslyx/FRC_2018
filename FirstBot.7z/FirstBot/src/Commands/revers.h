#ifndef revers_H
#define revers_H

#include "Commands/Command.h"

class revers : public Command {
public:
	double speed;
	revers(double x_speed);
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
};

#endif  // revers_H
