#include "forward.h"
#include "../Robot.h"

forward::forward(double x_speed) {
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(Robot::chassis.get());
	Requires(&Robot::drivetrain);
	SetTimeout(3);
	this->speed=x_speed;
}

// Called just before this Command runs the first time
void forward::Initialize() {

}

// Called repeatedly when this Command is scheduled to run
void forward::Execute() {
	Robot::drivetrain.leftSpeed(this->speed);
	Robot::drivetrain.rightSpeed(this->speed);
}

// Make this return true when this Command no longer needs to run execute()
bool forward::IsFinished() {
	return IsTimedOut();
}

// Called once after isFinished returns true
void forward::End() {
	Robot::drivetrain.leftSpeed(0);
	Robot::drivetrain.rightSpeed(0);

}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void forward::Interrupted() {
	this->End();
}
