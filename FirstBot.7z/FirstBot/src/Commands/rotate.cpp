#include "rotate.h"
#include "Robot.h"

rotate::rotate(double x_speed) {
	// Use Requires() here to declare subsystem dependencies
	// eg. Requires(Robot::chassis.get());
	Requires(&Robot::drivetrain);
	this->speed=x_speed;
}

// Called just before this Command runs the first time
void rotate::Initialize() {

}

// Called repeatedly when this Command is scheduled to run
void rotate::Execute() {
	Robot::drivetrain.leftSpeed(-this->speed);
	Robot::drivetrain.rightSpeed(this->speed);

}

// Make this return true when this Command no longer needs to run execute()
bool rotate::IsFinished() {
	return false;
}

// Called once after isFinished returns true
void rotate::End() {
	Robot::drivetrain.rightSpeed(0);
	Robot::drivetrain.leftSpeed(0);
}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void rotate::Interrupted() {
	this->End();
}
