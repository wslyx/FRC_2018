#ifndef ButtonResponse_H
#define ButtonResponse_H

#include "Commands/Command.h"
#include <Joystick.h>
#include <DigitalInput.h>
#include <Spark.h>

class ButtonResponse : public Command {
public:
	ButtonResponse();
	void Initialize();
	void Execute();
	bool IsFinished();
	void End();
	void Interrupted();
private:
	//Init
		frc::Joystick *myJS_2 = new frc::Joystick(1);				//�ֱ�
		double LAxisY=0,LAxisX=0,RAxisY=0,RAxisX=0,LT=0,RT=0;		//�ֱ�����
		bool A=0,B=0,X=0,Y=0,LB=0,RB=0,LP=0,RP=0,BACK=0,START=0;
		int myPOV=0;												//�ֱ�����
		frc::DigitalInput* limitSwitch= new frc::DigitalInput(1);
		//end

};

#endif  // ButtonResponse_H
