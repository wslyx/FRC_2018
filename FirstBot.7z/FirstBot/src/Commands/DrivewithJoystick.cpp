#include "DrivewithJoystick.h"
#include "Robot.h"
#include <iostream>

DrivewithJoystick::DrivewithJoystick() {
	Requires(&Robot::drivetrain);
}

// Called just before this Command runs the first time
void DrivewithJoystick::Initialize() {
	this->now=0;
}

// Called repeatedly when this Command is scheduled to run
void DrivewithJoystick::Execute() {
	//get value from joystick
	LAxisY = myJS_1->GetRawAxis(1);
	LAxisX = myJS_1->GetRawAxis(0);
//	RAxisY = myJS_1->GetRawAxis(5);
//	RAxisX = myJS_1->GetRawAxis(4);
//	myPOV = myJS_1->GetPOV();
//	A = myJS_1->GetRawButton(1);
//	B = myJS_1->GetRawButton(2);
//	X = myJS_1->GetRawButton(3);
//	Y = myJS_1->GetRawButton(4);
//	LB = myJS_1->GetRawButton(5);
//	RB = myJS_1->GetRawButton(6);
//	BACK = myJS_1->GetRawButton(7);
//	START = myJS_1->GetRawButton(8);
//	LP = myJS_1->GetRawButton(9);
//	RP = myJS_1->GetRawButton(10);
//	LT=myJS_1->GetRawAxis(2);
//	RT=myJS_1->GetRawAxis(3);
	//end

	if(now < -LAxisY){
		now=now+0.018;
	}else if(now > -LAxisY){
		now=now-0.018;
	}

	Robot::drivetrain.leftSpeed(0.5*now+0.5*LAxisX);
	Robot::drivetrain.rightSpeed(0.5*now-0.5*LAxisX);
}

// Make this return true when this Command no longer needs to run execute()
bool DrivewithJoystick::IsFinished() {
	return false;
}

// Called once after isFinished returns true
void DrivewithJoystick::End() {
	Robot::drivetrain.leftSpeed(0);
	Robot::drivetrain.rightSpeed(0);
}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void DrivewithJoystick::Interrupted() {

}
