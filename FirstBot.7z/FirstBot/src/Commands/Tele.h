#ifndef Tele_H
#define Tele_H

#include <Commands/CommandGroup.h>

class Tele : public CommandGroup {
public:
	Tele();
};

#endif  // Tele_H
