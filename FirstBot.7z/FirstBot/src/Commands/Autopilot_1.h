#ifndef Autopilot_1_H
#define Autopilot_1_H

#include <Commands/CommandGroup.h>

class Autopilot_1 : public CommandGroup {
public:
	Autopilot_1();
};

#endif  // Autopilot_1_H
