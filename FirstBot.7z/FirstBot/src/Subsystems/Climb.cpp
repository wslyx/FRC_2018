#include "Climb.h"
#include <iostream>
#include <Spark.h>

Climb::Climb()
		: Subsystem("Climb"){

}

void Climb::up(){
	this->SP->Set(0.2);
}

void Climb::down(){
	this->SP->Set(0.2);
}

void Climb::off(){
	this->SP->Set(0);
}
