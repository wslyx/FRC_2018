#include "IntakeUD.h"
#include <iostream>
#include <Spark.h>

IntakeUD::IntakeUD() : Subsystem("IntakeUD") {

}

void IntakeUD::up(){
	this->SP1->Set(-0.4);
}

void IntakeUD::down(){
	this->SP1->Set(0.4);
}

void IntakeUD::off(){
	this->SP1->Set(0);
}
