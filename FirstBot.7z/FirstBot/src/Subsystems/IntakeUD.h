#ifndef IntakeUD_H
#define IntakeUD_H

#include <Commands/Subsystem.h>
#include <Spark.h>

class IntakeUD : public Subsystem {
private:
	frc::Spark *SP1 = new frc::Spark(0);
public:
	IntakeUD();
	void up();
	void down();
	void off();
};

#endif  // IntakeUD_H
