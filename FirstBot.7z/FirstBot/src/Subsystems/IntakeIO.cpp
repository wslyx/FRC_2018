#include "IntakeIO.h"
#include <Timer.h>
#include <iostream>
#include <Spark.h>
#include <Commands/Subsystem.h>


IntakeIO::IntakeIO() : frc::Subsystem("IntakeIO") {

}

void IntakeIO::in(){
	this->Solenoid->Set(true);
	this->SP->Set(0.7);
}

void IntakeIO::out(){
	this->SP->Set(-0.7);
//	frc::Wait(1);
	this->Solenoid->Set(false);
}

void IntakeIO::c_on(){
	this->c->SetClosedLoopControl(true);
}

void IntakeIO::c_off(){
	this->c->SetClosedLoopControl(false);
}

void IntakeIO::off(){
	this->SP->Set(0);
}
