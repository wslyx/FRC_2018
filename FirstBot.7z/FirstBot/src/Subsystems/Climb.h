#ifndef Climb_H
#define Climb_H

#include <Commands/Subsystem.h>
#include <Spark.h>

class Climb : public Subsystem {
private:
	// It's desirable that everything possible under private except
	// for methods that implement subsystem capabilities

public:
	Climb();
	void up();
	void down();
	void off();
private:
	frc::Spark *SP = new frc::Spark(8);
};

#endif  // Climb_H
