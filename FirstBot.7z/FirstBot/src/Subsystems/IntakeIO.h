#ifndef IntakeIO_H
#define IntakeIO_H

#include <Commands/Subsystem.h>
#include <Spark.h>
#include <Compressor.h>
#include <Solenoid.h>

class IntakeIO : public Subsystem {
private:
	// It's desirable that everything possible under private except
	// for methods that implement subsystem capabilities
	frc::Spark *SP = new frc::Spark(5);
	frc::Compressor *c = new frc::Compressor(0);
	frc::Solenoid *Solenoid = new frc::Solenoid(0);

public:
	IntakeIO();
	void in();
	void out();
	void off();
	void c_on();
	void c_off();
};

#endif  // IntakeIO_H
