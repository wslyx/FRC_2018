/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#include "Robot.h"
#include <iostream>

DriveTrain Robot::drivetrain;
Climb Robot::climb;
IntakeIO Robot::intakeio;
IntakeUD Robot::intakeud;


void Robot::RobotInit() {
	// Show what command your subsystem is running on the SmartDashboard
//	frc::SmartDashboard::PutData(&drivetrain);

	CameraServer::GetInstance()->StartAutomaticCapture();

	Robot::intakeio.c_on();
}

void Robot::AutonomousInit() {
	DriverStation &ds = DriverStation::GetInstance();
	std::string gameData=ds.GetGameSpecificMessage();
	const char *p= gameData.c_str();

	if (*p == 'L') {
		std::cout<<"Receive LLLLLLLLL"<<std::endl;
		m_autonomousCommand = &myAuto_1;
	} else {
		std::cout<<"Receive is not LL"<<std::endl;
		m_autonomousCommand = &myAuto_2;
	}

	if (m_autonomousCommand != nullptr) {
		m_autonomousCommand->Start();
		std::cout << "Starting Auto" << std::endl;
	}
}

void Robot::AutonomousPeriodic() {
	frc::Scheduler::GetInstance()->Run();
}

void Robot::TeleopInit() {
	// This makes sure that the autonomous stops running when
	// teleop starts running. If you want the autonomous to
	// continue until interrupted by another command, remove
	// this line or comment it out.
	if (m_autonomousCommand != nullptr) {
		m_autonomousCommand->Cancel();
		m_autonomousCommand = nullptr;
	}

}

void Robot::TeleopPeriodic() {
	frc::Scheduler::GetInstance()->Run();

	this->m_shou=&this->tele;
	m_shou->Start();
//	Robot::intakeio.c_on();
}

void Robot::TestPeriodic() {}

START_ROBOT_CLASS(Robot)
