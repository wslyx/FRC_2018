/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include <Commands/Command.h>
#include <Commands/Scheduler.h>
#include <IterativeRobot.h>
#include <LiveWindow/LiveWindow.h>
#include <SmartDashboard/SmartDashboard.h>

#include "Commands/Autopilot_1.h"
#include "Commands/Autopilot_2.h"
#include "Commands/Tele.h"
#include "Subsystems/DriveTrain.h"
#include <CameraServer.h>
#include <string>
#include <DriverStation.h>
#include <iostream>
#include "SubSystems/Climb.h"
#include "SubSystems/IntakeIO.h"
#include "SubSystems/IntakeUD.h"

class Robot : public frc::IterativeRobot {
public:
	static DriveTrain drivetrain;
	static IntakeIO intakeio;
	static IntakeUD intakeud;
	static Climb climb;

private:
	frc::Command* m_autonomousCommand = nullptr;
	Autopilot_1 myAuto_1;
	Autopilot_2 myAuto_2;

	frc::Command* m_shou = nullptr;
	Tele tele;
	frc::LiveWindow& m_lw = *frc::LiveWindow::GetInstance();

	void RobotInit() override;
	void AutonomousInit() override;
	void AutonomousPeriodic() override;
	void TeleopInit() override;
	void TeleopPeriodic() override;
	void TestPeriodic() override;
};
